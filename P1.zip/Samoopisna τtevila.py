st = (input("Vnesi število: "))
list1 = [st]
n = len(st)

for i in range(n):
    if i == '0':
        print(list1.coun('1'))
