def delitelji(n):
    s = []
    i = 2
    while i <= n:
        if n % i == 0:
            return i
        i += 1

    return s

i = 1
while i < 100:
    print(i, ":", delitelji(i))
    i += 1

