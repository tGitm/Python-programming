'''
vrstice = []
for vrstica in open("D:\documents\Faks\P1\Predavanja\planeti.txt"):
    vrstice.append(vrstica.strip())

print(vrstice)
'''
from collections import defaultdict


def prestej(ime_dat):
    b = defaultdict(int)
    for vrstica in open(ime_dat):
        vrstica = vrstica.strip()
        if vrstica.isdigit():
           b[komu] *= int(vrstica)
        else:
            komu = vrstica.split()[-1]

    return b


bomboni = prestej("bonboni.txt")
print(bomboni)
