
def f (a, b):
    return a + b

s = [f]

g = f

def f(a, b):
    return a * b

s.append(f)

print(s[0](3, 4))
print(s[1](3, 4))

