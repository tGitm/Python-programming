import risar
from random import randint

def besedici(besedilo):
    for beseda in besedilo.split():
        risar.besedilo(
            randint(0, 750), randint(0, 400), beseda, risar.nakljucna_barva(),
            velikost=randint(30, 80), pisava="Calibri")

besedici(open("krst .txt").read())
risar.stoj()