
def f(a, b):
    a = 2

    b.append(3)
    b = b[:]
    b.append(4)
    print("b:", b)
    '''b.append(3)
    print("b is y", b is y)
    b = []
    print("b is y", b is y)
    b.append(4)
'''

x = 3
y = [1, 2]
f(x, y)

print("x:", x)
print("y:", y)
