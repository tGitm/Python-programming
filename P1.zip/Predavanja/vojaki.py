from random import choice

import risar



desetarji = [(10, 475), (537, 475), (271, 10)]

vojskax, vojskay = 6, 13

for i in range(1000):
    kjex, kjey = choice(desetarji)
    vojskax, vojskay = (vojskax + kjex) / 2, (vojskay + kjey) / 2
    risar.tocka(vojskax, vojskay)
    risar.cakaj(0.01)

for i in range(1000):
    kjex, kjey = choice(desetarji)
    vojskax, vojskay = (vojskax + kjex) / 2, (vojskay + kjey) / 2
    risar.tocka(vojskax, vojskay)
    risar.cakaj(0.01)

for i in range(1000):
    kjex, kjey = choice(desetarji)
    vojskax, vojskay = (vojskax + kjex) / 2, (vojskay + kjey) / 2
    risar.tocka(vojskax, vojskay)
    risar.cakaj(0.01)