class Oseba:

    def __init__(self, ime, spol):
        self.ime = ime
        self.spol = spol

    def pozdravi(self):
        print("Pozdravljeni, jaz sem ", self.ime, "in sem", self.kaj_sem())

    def kaj_sem(self):
        if self.spol == "Ž":
            return "gospa"

        else:
            return "gospod"


class Student(Oseba):
    def __init__(self, ime, spol):
        super().__init__(ime, spol)
        self.ocene = {}

    def kaj_sem(self):
        if self.spol == "Ž":
            return "študentka"

        else:
            return "študent"


    def oceni(self, predmet, ocena):
        self.ocene[predmet] = ocena

    def povprecje(self):
        return sum(self.ocene.values()) / len(self.ocene)


class Ucitelj(Oseba):
    def __init__(self, ime, spol, naziv):
        super().__init__(ime, naziv)
        self.spol = spol

    def kaj_sem(self):
        if self.spol == "Ž":
            return "docentka"

        else:
            return "docent"

    def predavaj(self):
        print("bla bla bla")


class Snazilka(Oseba):
    def __init__(self):
        super().__init__("Fata", "Ž")
        self.stevilka = 18

    def kaj_sem(self):
        if self.spol == "Ž":
            return "fatima"

        else:
            return "fatimac"

    def stevilka_avtobusa(self):
        return self.stevilka


ana = Oseba("Ana", "Ž")
ana.pozdravi()

berta = Oseba("Berta", "Ž")
ana.pozdravi()

cilka = Student("Cilka", "Ž")
cilka.pozdravi()
cilka.oceni("Matematika", 10)
cilka.oceni("Uvod v računalništvo", 7)
print(cilka.povprecje())

dani = Ucitelj("Dani", "Ž", "docentka")
dani.pozdravi()
dani.predavaj()

fata = Snazilka()
fata.stevilka_avtobusa()
fata.pozdravi()

