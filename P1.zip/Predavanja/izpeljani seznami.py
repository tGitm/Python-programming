

def g(x):
    return x ** 2
def f(a, b):
    print(x)

    '''print("prej: ")
    print(" a", a)
    print(" b", b)

    t = a
    a = b
    b = t

    a, b = b, a
    print(" potem: ")
    print(" a", a)
    print(" b", b)

    x = a
    y = b

    print("  x:", x)
'''


x = 3
y = 4
f(x, y)
print("x:", x)
