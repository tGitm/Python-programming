import zelva
import risar
from random import randint, random, choice

turtles = []
for i in range(20):
    t = zelva.Turtle()
    t.turn(randint(0, 360))
    turtles.append(t)

for i in range(10000):
    t = choice(turtles)
    t.turn(randint(-30, 30))
    t.forward(10)


t.wait()