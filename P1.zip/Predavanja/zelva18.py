from math import sin, cos, radians
import risar


class Turtle:
    def __init__(self):
        self.x = 300
        self.y = 300
        self.angle = 0
        self.drawing = True

        self.trup = risar.krog(0, 0, 5, risar.zelena, 3)
        self.glava = risar.krog(0, 0, 2, risar.zelena, 3)
        self._update()

    def _update(self):
        self.trup.setPos(self.x, self.y)
        self.glava.setPos(self.x + 5 * cos(radians(self.angle)),
                          self.y - 5 * cos(radians(self.angle)))

    def forward(self, a):
        x1 = self.x + a * cos(radians(self.angle))
        y1 = self.y - a * sin(radians(self.angle))

        if self.drawing():
            risar.crta(self.x, self.y, x1, y1)
        self.x, self.y = x1, y1
        self._update()

    def turn(self, phi):
        self.angle += phi
        self._update

    def fly(self, x, y, angle):
        self.x = x
        self.y = y
        self.angle = angle
        self._update()

    def backward(self, a):
        self.forward(-a)
        self._update()

    def left(self):
        self.turn(90)
        self._update()

    def right(self):
        self.turn(-90)
        self._update()

    def pen_up(self):
        self.drawing = False

    def pen_down(self):
        self.drawing = True


ana = Turtle()




#for i in range(72):
for i in range(50):
        ana.forward(5)
        ana.pen_up()
        ana.forward(5)
        ana.pen_down()
#        ana.turn(90)
#       risar.cakaj(1)
#       ana.turn(5)

risar.stoj()