import zelva
import risar

berta = zelva.Turtle()


def veja(z, a):
    z.forward(a)
    if a > 5:
        z.turn(30)
        veja(z, a / 1.5)
        z.turn(-60)
        veja(z, a / 1.5)
    z.backward(a)


for i in range(6):
    veja(berta, 60)
    berta.turn(50)

risar.stoj()