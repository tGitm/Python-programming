podatki = [
    (74, "Benjamin", True),
    (65, "Cilka", False),
    (87, "Marjan", True),
    (71, "Tini", False),
    (160, "Gasper", True)
]


def delitelji(n):
    s = []
    for i in range(1, n + 1):
        if n % i == 0:
            s.append(i)
    return s

def delitelji(n):
    return

s = {n: delitelji(n) for n in range(0, 100)
        for n in range(0, 100)
            if n % 2 == 0}

print(S)

