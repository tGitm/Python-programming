import zelva
import risar


def zlomljena(z, a):
    if a < 5:
        z.forward(a)
    else:
        zlomljena(z, a / 3)
        z.turn(-60)
        zlomljena(z, a / 3)
        z.turn(120)
        zlomljena(z, a / 3)
        z.turn(-60)
        zlomljena(z, a / 3)


berta = zelva.Turtle()
berta.fly(100, 120, 90)
zlomljena(berta, 400)

risar.stoj()