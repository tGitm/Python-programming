import risar
from random import randint

for i in range(100):
    x0, y0 = risar.nakljucne_koordinate()
    x1, y1 = risar.nakljucne_koordinate()
    barva = risar.barva(randint(0, 255), randint(0, 255), randint(0, 255))
    sirina = randint(2, 20)
    risar.crta(x0, y0, x1, y1, barva, sirina)
risar.stoj()