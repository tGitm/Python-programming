import risar
import os
from random import randint
slike = os.listdir("slike")

for fn in os.listdir("slike"):
    risar.slika(randint(0, risar.maxX-100), randint(0, risar.maxY-100),
                "slike/"+fn)

    risar.stoj()