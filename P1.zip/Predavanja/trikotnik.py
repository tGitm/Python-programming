import risar

def trikotnik(x0, y0, x1, y1, x2, y2):
    risar.crta(x0, y0, x1, y1)
    risar.crta(x2, y2, x1, y1)
    risar.crta(x2, y2, x0, y0)

def vrisi_trikotnik(Ax, Ay, Bx, By, Cx, Cy):
    ACx, ACy = (Ax + Cx) / 2, (Ay + Cy) / 2
    BCx, BCy = (Bx + Cx) / 2, (By + Cy) / 2
    ABx, ABy = (Ax + Bx) / 2, (Ay + By) / 2
    trikotnik(ACx, ACy, BCx, BCy, ABx, ABy)
    if (Bx - Ax) > 10:
        vrisi_trikotnik(Ax, Ay, ABx, ABy, ACx, ACy)
        vrisi_trikotnik(ACx, ACy, BCx, BCy, Cx, Cy)
        vrisi_trikotnik(ABx, ABy, Bx, By, BCx, BCy)



Ax, Ay = 10, 475
Bx, By = 537, 475
Cx, Cy = 271, 10

trikotnik(Ax, Ay, Bx, By, Cx, Cy)
vrisi_trikotnik(Ax, Ay, Bx, By, Cx, Cy)
risar.stoj()