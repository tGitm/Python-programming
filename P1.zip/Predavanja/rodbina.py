otroci = {
    "Adam": ["Matjaž", "Cilka", "Daniel"],
    "Aleksander": [],
    "Alenka": [],
    "Barbara": [],
    "Cilka": [],
    "Daniel": ["Elizabeta", "Hans"],
    "Erik": [],
    "Elizabeta": ["Ludvik", "Jurij", "Barbara"],
    "Franc": [],
    "Herman": ["Margareta"],
    "Hans": ["Herman", "Erik"],
    "Jožef": ["Alenka", "Aleksander", "Petra"],
    "Jurij": ["Franc", "Jožef"],
    "Ludvik": [],
    "Margareta": [],
    "Matjaž": ["Viljem"],
    "Petra": [],
    "Tadeja": [],
    "Viljem": ["Tadeja"],
}


def stevilo_otrok(oseba):
    return len(otroci[oseba])


def stevilo_vnukov(oseba):
    v = 0
    for otrok in otroci[oseba]:
        v += stevilo_otrok[oseba]
    return v


def velikost_rodbine(oseba):
    v = 1
    for otrok in otroci[oseba]:
        v += velikost_rodbine(otrok)
    return v


def obstaja(ime, oseba):
    if ime == oseba:
        return True

    for otrok in otroci[oseba]:
        if obstaja(ime, otrok):
            return True
    return False


print(obstaja("Daniel", "Daniel"))