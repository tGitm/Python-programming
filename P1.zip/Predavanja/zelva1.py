import turtle
import risar

berta = turtle.Turtle()

for i in range(5):
    berta.forward(10)
    berta.turn(360 / 60)



risar.stoj()