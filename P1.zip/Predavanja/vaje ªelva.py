import risar

class Turtle:

    def turn_around(self):
        self.turn(180)


t = Turtle()
t.turn_around()


risar.stoj()